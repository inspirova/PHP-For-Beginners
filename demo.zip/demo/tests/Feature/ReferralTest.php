<?php

it('allows subscribers to earn money by referring their friends', function () {
    //Referral
    // redeems
});

it('disallows guest from participating in the referral program', function () {

});