<?php

view('registration/create.view.php');
