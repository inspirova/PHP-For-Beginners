<!doctype html>
<html lang="en" class="h-full bg-gray-100">
<head>
    <title>Demo</title>
</head>
<script src="https://cdn.tailwindcss.com"></script>
<body class="h-full">
<div class="min-h-full">